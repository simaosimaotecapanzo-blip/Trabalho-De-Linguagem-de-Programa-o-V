@echo off
cd /d "%~dp0"
py sistema_filas.py
if errorlevel 1 python sistema_filas.py
pause
