"""
Sistema de Gestão de Filas de Espera e Atendimento
Hospital Geral do Uíge
Projeto académico demonstrativo — Python + Tkinter + SQLite

AVISO: Utilize apenas dados fictícios. Esta aplicação é um protótipo académico,
não um sistema clínico certificado nem adequado para uso hospitalar real.
A prioridade clínica deve ser atribuída por profissional autorizado segundo
os protocolos institucionais; o programa apenas respeita a prioridade registada.
"""

import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).with_name("filas_hospital.db")

PRIORIDADES = {
    "Emergência": 1,
    "Urgente": 2,
    "Prioridade legal": 3,
    "Normal": 4,
}

ESTADOS = ("Aguardar", "Chamado", "Em atendimento", "Concluído", "Cancelado")


def ligar_bd():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def inicializar_bd():
    with ligar_bd() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS salas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL UNIQUE,
            enfermeiro TEXT NOT NULL,
            medico TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS utentes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL UNIQUE,
            nome TEXT NOT NULL,
            idade INTEGER,
            contacto TEXT,
            sala_id INTEGER NOT NULL,
            prioridade TEXT NOT NULL,
            motivo_prioridade TEXT,
            data_registo TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'Aguardar',
            FOREIGN KEY (sala_id) REFERENCES salas(id)
        );

        CREATE TABLE IF NOT EXISTS eventos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            utente_id INTEGER NOT NULL,
            acao TEXT NOT NULL,
            data_hora TEXT NOT NULL,
            observacao TEXT,
            FOREIGN KEY (utente_id) REFERENCES utentes(id)
        );
        """)
        total = con.execute("SELECT COUNT(*) FROM salas").fetchone()[0]
        if total == 0:
            con.executemany(
                "INSERT INTO salas(nome, enfermeiro, medico) VALUES (?, ?, ?)",
                [
                    ("Medicina Geral", "Enf.ª Ana Manuel", "Dr. Paulo António"),
                    ("Pediatria", "Enf.ª Rosa Miguel", "Dr. João Pedro"),
                    ("Maternidade", "Enf.ª Maria José", "Dra. Isabel Domingos"),
                    ("Estomatologia", "Enf. Carlos Mateus", "Dr. Alberto Zola"),
                ],
            )


def registar_evento(con, utente_id, acao, observacao=""):
    con.execute(
        "INSERT INTO eventos(utente_id, acao, data_hora, observacao) VALUES (?, ?, ?, ?)",
        (utente_id, acao, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), observacao),
    )


class SistemaFilas:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Gestão de Filas — Hospital Geral do Uíge")
        self.root.geometry("1180x720")
        self.root.minsize(980, 620)
        self.root.configure(bg="#eef2f6")
        self.estilizar()
        self.criar_interface()
        self.atualizar_tudo()

    def estilizar(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#eef2f6")
        style.configure("Card.TFrame", background="white")
        style.configure("TLabel", background="#eef2f6", font=("Segoe UI", 10))
        style.configure("Titulo.TLabel", font=("Segoe UI", 19, "bold"), foreground="#12304a")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#536575")
        style.configure("Treeview", rowheight=27, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        style.configure("TButton", font=("Segoe UI", 9, "bold"), padding=7)
        style.configure("Accent.TButton", background="#126782", foreground="white")
        style.map("Accent.TButton", background=[("active", "#0d5269")])

    def criar_interface(self):
        topo = tk.Frame(self.root, bg="#12304a", height=88)
        topo.pack(fill="x")
        topo.pack_propagate(False)
        tk.Label(topo, text="HOSPITAL GERAL DO UÍGE", bg="#12304a", fg="white",
                 font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=24, pady=(13, 0))
        tk.Label(topo, text="Sistema de Gestão de Filas de Espera e Atendimento de Utentes",
                 bg="#12304a", fg="#d7e7ef", font=("Segoe UI", 10)).pack(anchor="w", padx=25)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=14)

        self.painel = ttk.Frame(self.tabs, padding=14)
        self.registo = ttk.Frame(self.tabs, padding=14)
        self.fila = ttk.Frame(self.tabs, padding=14)
        self.salas = ttk.Frame(self.tabs, padding=14)
        self.historico = ttk.Frame(self.tabs, padding=14)

        self.tabs.add(self.painel, text="Painel")
        self.tabs.add(self.registo, text="Registar utente")
        self.tabs.add(self.fila, text="Fila e atendimento")
        self.tabs.add(self.salas, text="Salas e profissionais")
        self.tabs.add(self.historico, text="Histórico")

        self.criar_painel()
        self.criar_registo()
        self.criar_fila()
        self.criar_salas()
        self.criar_historico()

        rodape = tk.Label(self.root,
            text="Protótipo académico • Use exclusivamente dados fictícios • Prioridades definidas por pessoal autorizado",
            bg="#eef2f6", fg="#657786", font=("Segoe UI", 8))
        rodape.pack(pady=(0, 8))

    def criar_painel(self):
        ttk.Label(self.painel, text="Painel de controlo", style="Titulo.TLabel").pack(anchor="w")
        ttk.Label(self.painel, text="Resumo operacional da fila de atendimento.", style="Sub.TLabel").pack(anchor="w", pady=(2, 14))
        cards = ttk.Frame(self.painel)
        cards.pack(fill="x", pady=4)
        self.metricas = {}
        for chave, titulo in [
            ("Aguardar", "Aguardam atendimento"),
            ("Chamado", "Chamados"),
            ("Em atendimento", "Em atendimento"),
            ("Concluído", "Atendimentos concluídos"),
        ]:
            card = tk.Frame(cards, bg="white", highlightbackground="#d8e0e7", highlightthickness=1)
            card.pack(side="left", fill="both", expand=True, padx=(0, 10), ipady=12)
            tk.Label(card, text=titulo, bg="white", fg="#536575", font=("Segoe UI", 9)).pack(pady=(10, 4))
            valor = tk.Label(card, text="0", bg="white", fg="#126782", font=("Segoe UI", 23, "bold"))
            valor.pack(pady=(0, 10))
            self.metricas[chave] = valor

        ttk.Label(self.painel, text="Próximos utentes na fila", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(20, 8))
        cols = ("numero", "nome", "sala", "prioridade", "hora")
        self.tree_painel = ttk.Treeview(self.painel, columns=cols, show="headings", height=9)
        nomes = {"numero":"N.º atendimento", "nome":"Utente", "sala":"Sala", "prioridade":"Prioridade", "hora":"Registado em"}
        larguras = {"numero":130, "nome":260, "sala":190, "prioridade":150, "hora":160}
        for c in cols:
            self.tree_painel.heading(c, text=nomes[c])
            self.tree_painel.column(c, width=larguras[c], anchor="w")
        self.tree_painel.pack(fill="both", expand=True)

    def criar_registo(self):
        ttk.Label(self.registo, text="Registo de chegada do utente", style="Titulo.TLabel").pack(anchor="w")
        ttk.Label(self.registo, text="Preencha os dados e selecione a sala de destino.", style="Sub.TLabel").pack(anchor="w", pady=(2, 15))
        form = ttk.Frame(self.registo)
        form.pack(anchor="nw", fill="x")
        self.v_nome = tk.StringVar()
        self.v_idade = tk.StringVar()
        self.v_contacto = tk.StringVar()
        self.v_sala = tk.StringVar()
        self.v_prioridade = tk.StringVar(value="Normal")
        self.v_motivo = tk.StringVar()

        campos = [
            ("Nome completo *", self.v_nome),
            ("Idade", self.v_idade),
            ("Contacto (opcional)", self.v_contacto),
        ]
        for i, (rotulo, var) in enumerate(campos):
            ttk.Label(form, text=rotulo).grid(row=i, column=0, sticky="w", padx=(0, 12), pady=8)
            ttk.Entry(form, textvariable=var, width=42).grid(row=i, column=1, sticky="w", pady=8)

        ttk.Label(form, text="Sala de atendimento *").grid(row=3, column=0, sticky="w", padx=(0, 12), pady=8)
        self.combo_sala = ttk.Combobox(form, textvariable=self.v_sala, state="readonly", width=39)
        self.combo_sala.grid(row=3, column=1, sticky="w", pady=8)

        ttk.Label(form, text="Prioridade *").grid(row=4, column=0, sticky="w", padx=(0, 12), pady=8)
        ttk.Combobox(form, textvariable=self.v_prioridade, values=list(PRIORIDADES), state="readonly", width=39).grid(row=4, column=1, sticky="w", pady=8)

        ttk.Label(form, text="Justificação da prioridade").grid(row=5, column=0, sticky="w", padx=(0, 12), pady=8)
        ttk.Entry(form, textvariable=self.v_motivo, width=42).grid(row=5, column=1, sticky="w", pady=8)

        ttk.Label(self.registo, text="A prioridade clínica/legal deve ser confirmada por profissional autorizado.",
                  foreground="#8a4b08").pack(anchor="w", pady=(12, 8))
        ttk.Button(self.registo, text="Registar utente e emitir senha", style="Accent.TButton",
                   command=self.registar_utente).pack(anchor="w", pady=10)

    def criar_fila(self):
        ttk.Label(self.fila, text="Gestão da fila de espera", style="Titulo.TLabel").pack(anchor="w")
        ttk.Label(self.fila, text="A fila é ordenada por prioridade e, dentro da mesma prioridade, pela hora de chegada.",
                  style="Sub.TLabel").pack(anchor="w", pady=(2, 12))
        barra = ttk.Frame(self.fila)
        barra.pack(fill="x", pady=(0, 8))
        ttk.Label(barra, text="Filtrar por sala:").pack(side="left")
        self.filtro_sala = tk.StringVar(value="Todas")
        self.combo_filtro = ttk.Combobox(barra, textvariable=self.filtro_sala, state="readonly", width=25)
        self.combo_filtro.pack(side="left", padx=8)
        self.combo_filtro.bind("<<ComboboxSelected>>", lambda e: self.atualizar_fila())
        ttk.Button(barra, text="Atualizar", command=self.atualizar_fila).pack(side="left", padx=4)

        cols = ("numero", "nome", "sala", "prioridade", "hora", "estado", "responsaveis")
        self.tree_fila = ttk.Treeview(self.fila, columns=cols, show="headings", height=15)
        cab = {"numero":"Senha", "nome":"Utente", "sala":"Sala", "prioridade":"Prioridade", "hora":"Chegada", "estado":"Estado", "responsaveis":"Enfermeiro / Médico"}
        larg = {"numero":100, "nome":180, "sala":140, "prioridade":125, "hora":140, "estado":120, "responsaveis":260}
        for c in cols:
            self.tree_fila.heading(c, text=cab[c])
            self.tree_fila.column(c, width=larg[c], anchor="w")
        self.tree_fila.pack(fill="both", expand=True)

        botoes = ttk.Frame(self.fila)
        botoes.pack(fill="x", pady=10)
        ttk.Button(botoes, text="Chamar próximo", style="Accent.TButton", command=self.chamar_proximo).pack(side="left", padx=(0, 6))
        ttk.Button(botoes, text="Iniciar atendimento", command=lambda: self.alterar_estado("Em atendimento")).pack(side="left", padx=6)
        ttk.Button(botoes, text="Concluir atendimento", command=lambda: self.alterar_estado("Concluído")).pack(side="left", padx=6)
        ttk.Button(botoes, text="Cancelar registo", command=lambda: self.alterar_estado("Cancelado")).pack(side="left", padx=6)

    def criar_salas(self):
        ttk.Label(self.salas, text="Salas e profissionais responsáveis", style="Titulo.TLabel").pack(anchor="w")
        ttk.Label(self.salas, text="Cada sala está associada a um enfermeiro e a um médico.", style="Sub.TLabel").pack(anchor="w", pady=(2, 12))
        form = ttk.Frame(self.salas)
        form.pack(anchor="w", pady=(0, 12))
        self.nova_sala = tk.StringVar()
        self.novo_enf = tk.StringVar()
        self.novo_med = tk.StringVar()
        for i, (label, var) in enumerate([
            ("Nome da sala/serviço", self.nova_sala),
            ("Nome do enfermeiro", self.novo_enf),
            ("Nome do médico", self.novo_med),
        ]):
            ttk.Label(form, text=label).grid(row=i, column=0, sticky="w", padx=(0, 10), pady=5)
            ttk.Entry(form, textvariable=var, width=38).grid(row=i, column=1, sticky="w", pady=5)
        ttk.Button(form, text="Adicionar sala", command=self.adicionar_sala).grid(row=3, column=1, sticky="w", pady=8)

        self.tree_salas = ttk.Treeview(self.salas, columns=("sala", "enfermeiro", "medico"), show="headings", height=13)
        for c, t, w in [("sala","Sala/Serviço",260), ("enfermeiro","Enfermeiro responsável",260), ("medico","Médico responsável",260)]:
            self.tree_salas.heading(c, text=t)
            self.tree_salas.column(c, width=w, anchor="w")
        self.tree_salas.pack(fill="both", expand=True)

    def criar_historico(self):
        ttk.Label(self.historico, text="Histórico de movimentações", style="Titulo.TLabel").pack(anchor="w")
        ttk.Label(self.historico, text="Registos de emissão de senha, chamadas e alterações de estado.", style="Sub.TLabel").pack(anchor="w", pady=(2, 12))
        self.tree_hist = ttk.Treeview(self.historico, columns=("numero", "utente", "acao", "data", "obs"), show="headings", height=18)
        cab = {"numero":"Senha", "utente":"Utente", "acao":"Ação", "data":"Data e hora", "obs":"Observação"}
        for c in cab:
            self.tree_hist.heading(c, text=cab[c])
            self.tree_hist.column(c, width={"numero":100, "utente":190, "acao":180, "data":170, "obs":350}[c], anchor="w")
        self.tree_hist.pack(fill="both", expand=True)

    def carregar_salas(self):
        with ligar_bd() as con:
            rows = con.execute("SELECT * FROM salas ORDER BY nome").fetchall()
        self.salas_map = {r["nome"]: r["id"] for r in rows}
        self.combo_sala["values"] = list(self.salas_map)
        self.combo_filtro["values"] = ["Todas"] + list(self.salas_map)
        if rows and not self.v_sala.get():
            self.v_sala.set(rows[0]["nome"])

    def gerar_numero(self, con):
        hoje = datetime.now().strftime("%Y%m%d")
        prefixo = f"UIGE-{hoje}-"
        row = con.execute("SELECT COUNT(*) FROM utentes WHERE numero LIKE ?", (prefixo + "%",)).fetchone()
        return prefixo + f"{row[0] + 1:03d}"

    def registar_utente(self):
        nome = self.v_nome.get().strip()
        if not nome:
            messagebox.showwarning("Dados em falta", "Introduza o nome completo do utente.")
            return
        idade_txt = self.v_idade.get().strip()
        if idade_txt:
            try:
                idade = int(idade_txt)
                if idade < 0 or idade > 120:
                    raise ValueError
            except ValueError:
                messagebox.showwarning("Idade inválida", "A idade deve ser um número entre 0 e 120.")
                return
        else:
            idade = None
        sala = self.v_sala.get()
        if sala not in self.salas_map:
            messagebox.showwarning("Sala em falta", "Selecione uma sala de atendimento.")
            return
        prioridade = self.v_prioridade.get()
        motivo = self.v_motivo.get().strip()
        if prioridade != "Normal" and not motivo:
            messagebox.showwarning("Justificação necessária", "Registe a justificação da prioridade indicada.")
            return
        with ligar_bd() as con:
            numero = self.gerar_numero(con)
            cur = con.execute("""
                INSERT INTO utentes(numero, nome, idade, contacto, sala_id, prioridade,
                                    motivo_prioridade, data_registo, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Aguardar')
            """, (numero, nome, idade, self.v_contacto.get().strip(), self.salas_map[sala],
                  prioridade, motivo, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            registar_evento(con, cur.lastrowid, "Senha emitida", f"Prioridade: {prioridade}; Sala: {sala}")
        messagebox.showinfo("Registo efetuado", f"Utente registado com sucesso.\nNúmero de atendimento: {numero}")
        self.v_nome.set("")
        self.v_idade.set("")
        self.v_contacto.set("")
        self.v_prioridade.set("Normal")
        self.v_motivo.set("")
        self.atualizar_tudo()

    def obter_fila(self, sala_filtro=None):
        sql = """
            SELECT u.*, s.nome AS sala, s.enfermeiro, s.medico
            FROM utentes u JOIN salas s ON s.id = u.sala_id
            WHERE u.estado IN ('Aguardar', 'Chamado', 'Em atendimento')
        """
        args = []
        if sala_filtro and sala_filtro != "Todas":
            sql += " AND s.nome = ?"
            args.append(sala_filtro)
        sql += """
            ORDER BY CASE u.prioridade
                WHEN 'Emergência' THEN 1
                WHEN 'Urgente' THEN 2
                WHEN 'Prioridade legal' THEN 3
                ELSE 4 END,
                u.data_registo ASC, u.id ASC
        """
        with ligar_bd() as con:
            return con.execute(sql, args).fetchall()

    def atualizar_fila(self):
        for item in self.tree_fila.get_children():
            self.tree_fila.delete(item)
        for r in self.obter_fila(self.filtro_sala.get()):
            self.tree_fila.insert("", "end", iid=str(r["id"]), values=(
                r["numero"], r["nome"], r["sala"], r["prioridade"], r["data_registo"],
                r["estado"], f'{r["enfermeiro"]} / {r["medico"]}'
            ))

    def chamar_proximo(self):
        sala = self.filtro_sala.get()
        with ligar_bd() as con:
            sql = """
                SELECT u.* FROM utentes u JOIN salas s ON s.id=u.sala_id
                WHERE u.estado='Aguardar'
            """
            args = []
            if sala != "Todas":
                sql += " AND s.nome=?"
                args.append(sala)
            sql += """ ORDER BY CASE u.prioridade
                WHEN 'Emergência' THEN 1 WHEN 'Urgente' THEN 2
                WHEN 'Prioridade legal' THEN 3 ELSE 4 END,
                u.data_registo ASC, u.id ASC LIMIT 1"""
            row = con.execute(sql, args).fetchone()
            if not row:
                messagebox.showinfo("Fila vazia", "Não existem utentes a aguardar nesta seleção.")
                return
            con.execute("UPDATE utentes SET estado='Chamado' WHERE id=?", (row["id"],))
            registar_evento(con, row["id"], "Utente chamado", f'Senha {row["numero"]}')
        messagebox.showinfo("Chamada", f'Chamar o utente {row["numero"]} — {row["nome"]}.')
        self.atualizar_tudo()

    def alterar_estado(self, novo_estado):
        selecionado = self.tree_fila.selection()
        if not selecionado:
            messagebox.showwarning("Seleção necessária", "Selecione um utente na tabela da fila.")
            return
        utente_id = int(selecionado[0])
        with ligar_bd() as con:
            row = con.execute("SELECT numero, nome, estado FROM utentes WHERE id=?", (utente_id,)).fetchone()
            if not row:
                return
            permitidos = {
                "Em atendimento": ("Chamado", "Aguardar"),
                "Concluído": ("Em atendimento", "Chamado"),
                "Cancelado": ("Aguardar", "Chamado"),
            }
            if novo_estado in permitidos and row["estado"] not in permitidos[novo_estado]:
                messagebox.showwarning("Operação não permitida",
                    f'Não é possível alterar de "{row["estado"]}" para "{novo_estado}".')
                return
            con.execute("UPDATE utentes SET estado=? WHERE id=?", (novo_estado, utente_id))
            registar_evento(con, utente_id, f"Estado alterado: {novo_estado}", "")
        self.atualizar_tudo()

    def adicionar_sala(self):
        nome, enf, med = self.nova_sala.get().strip(), self.novo_enf.get().strip(), self.novo_med.get().strip()
        if not nome or not enf or not med:
            messagebox.showwarning("Dados em falta", "Preencha o nome da sala, do enfermeiro e do médico.")
            return
        try:
            with ligar_bd() as con:
                con.execute("INSERT INTO salas(nome, enfermeiro, medico) VALUES (?, ?, ?)", (nome, enf, med))
        except sqlite3.IntegrityError:
            messagebox.showerror("Sala existente", "Já existe uma sala com esse nome.")
            return
        self.nova_sala.set("")
        self.novo_enf.set("")
        self.novo_med.set("")
        self.atualizar_tudo()
        messagebox.showinfo("Sucesso", "Sala adicionada com sucesso.")

    def atualizar_painel(self):
        with ligar_bd() as con:
            for estado, widget in self.metricas.items():
                total = con.execute("SELECT COUNT(*) FROM utentes WHERE estado=?", (estado,)).fetchone()[0]
                widget.config(text=str(total))
        for item in self.tree_painel.get_children():
            self.tree_painel.delete(item)
        for r in self.obter_fila()[:10]:
            self.tree_painel.insert("", "end", values=(r["numero"], r["nome"], r["sala"], r["prioridade"], r["data_registo"]))

    def atualizar_salas(self):
        for item in self.tree_salas.get_children():
            self.tree_salas.delete(item)
        with ligar_bd() as con:
            rows = con.execute("SELECT * FROM salas ORDER BY nome").fetchall()
        for r in rows:
            self.tree_salas.insert("", "end", values=(r["nome"], r["enfermeiro"], r["medico"]))

    def atualizar_historico(self):
        for item in self.tree_hist.get_children():
            self.tree_hist.delete(item)
        with ligar_bd() as con:
            rows = con.execute("""
                SELECT u.numero, u.nome, e.acao, e.data_hora, e.observacao
                FROM eventos e JOIN utentes u ON u.id=e.utente_id
                ORDER BY e.id DESC LIMIT 300
            """).fetchall()
        for r in rows:
            self.tree_hist.insert("", "end", values=(r["numero"], r["nome"], r["acao"], r["data_hora"], r["observacao"] or ""))

    def atualizar_tudo(self):
        self.carregar_salas()
        self.atualizar_painel()
        self.atualizar_fila()
        self.atualizar_salas()
        self.atualizar_historico()


def main():
    inicializar_bd()
    root = tk.Tk()
    SistemaFilas(root)
    root.mainloop()


if __name__ == "__main__":
    main()
