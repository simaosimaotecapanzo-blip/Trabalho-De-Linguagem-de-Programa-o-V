#!/bin/sh
cd "$(dirname "$0")"
python3 sistema_filas.py
